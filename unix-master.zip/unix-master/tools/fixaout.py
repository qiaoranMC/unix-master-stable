#!/usr/bin/env python3
"""
Convert an 0407 binary into an 0405 binary, under the assumption
that the code starts at 040014 (by ".. = 40014").
See tools/as.
"""

import struct

def words(bs):
    l = len(bs) // 2  # 使用整数除法
    return list(struct.unpack('<%dH' % l, bs))

def unwords(ws):
    l = len(ws)
    return struct.pack('<%dH' % l, *ws)

def read(fn):
    with open(fn, 'rb') as f:  # 使用with语句自动管理文件关闭
        return f.read()

def write(fn, d):
    with open(fn, 'wb') as f:
        f.write(d)

# 读取原始文件并处理
d1 = words(read('a.out'))
hdr = d1[:8]
# 注意：在 Python 3 中，八进制数字必须以 '0o' 开头，而不是旧的 '0' 开头（那是 Python 2 的语法）
d = [0o405, 12 + hdr[1], 0, 0, hdr[4], 0] + d1[8:]
write("a.out", unwords(d))